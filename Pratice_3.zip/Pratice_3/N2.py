with open("beauty.txt","w")as f:
    f.write("Beauty and the Beast became good friends.\nOne fine morning, the men came riding on their horses and announced that the King and the Queen had invited all the maiden ladies of the kingdom to a royal ball.\n")
with open("beauty.txt","a")as f:
    f.write("The King saw beauty and fell in love with her.\nHe married her at the royal palace and lived happily together.")