fruits = {"orange","grape","cherry","apple"}
if "apple" in fruits:
 print("Yes, apple is a fruit!")
if "banana" not in fruits:
 print("Yes, grape is a fruit!")