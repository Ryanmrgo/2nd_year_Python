set1 = {10, 20, 30, 50}
set2 = {10, 30, 40}
set3={0}
set3=set1&set2

print (set3)