fruits = {"apple", "banana", "cherry"}

fruits.discard("cherry")

print(fruits)
'''
fruits.remove("apple")

print(fruits)

#Discard dont show error .
#Remove show error if it doesn't exist
'''