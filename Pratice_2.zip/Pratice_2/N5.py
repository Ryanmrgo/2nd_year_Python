myDC= {
  "New York" : {
    "Country" : "USA",
    "Population" : 8400000,
    "Fact":"Never Sleeps"
  },
  "Tokyo" : {
    "Country" : "Japan",
    "Population" : 13960000,
    "Fact":"Largest metropolitan area"
  },
  "Paris" : {
    "Country" : "France",
    "Population" : 2148000,
    "Fact":"City of love"
  },
  
}

print(myDC)